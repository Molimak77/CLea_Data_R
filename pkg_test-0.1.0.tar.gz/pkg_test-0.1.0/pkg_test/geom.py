#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Mar 16 12:36:26 2022

@author: molierenguile-makao
"""

class geormetry:
    def __init__(self,larg,long,haut=None):
        self.long=long
        self.larg=larg
        self.haut=haut
        
    def perimetre(self):
        if self.haut is None:
            return 2*(self.long+self.larg)
        else:
            return 2*(self.long+self.larg+self.haut)
        
    def volume(self):
        if self.haut is None:
            return "impossible de calculer le volume car pas de hauteur"
        else:
            return self.haut*self.larg*self.long
        
        